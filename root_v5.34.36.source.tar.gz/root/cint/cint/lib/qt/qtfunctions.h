/* -*- C++ -*- */
/*************************************************************************
 * Copyright(c) 1995~2005  Masaharu Goto (root-cint@cern.ch)
 *
 * For the licensing terms see the file COPYING
 *
 ************************************************************************/

#ifdef __CINT__
#pragma link off all functions;

#if 0
#pragma link off function operator>>(QTextStream&,int);
#pragma link off function operator<<(QTextStream&,int);
#pragma link off function operator>>(QTextStream&,void*&);
#pragma link off function operator<<(QTextStream&,void*&);
#pragma link off function qRemovePostRoutine(void (*)(void));
//#pragma link off function qt_testCollision(class QCanvasSprite const*,class QCanvasSprite const*);
#pragma link off function qt_unview(QCanvas*);
#pragma link off function qt_format_text(const QFontMetrics&,int,int,int,int,int,const QString&,int,QRect*,int,int*,int,char**,QPainter*);
#pragma link off function qInitPngIO;
#pragma link off function qt_builtin_gif_reader;
#pragma link off function operator<<(QTextStream&,const QDomNode&);
#endif
#endif

