# ----------------------------------------------------------------------  
# This model file was automatically created by SARAH version4.12.2 
# SARAH References: arXiv:0806.0538, arXiv:0909.2863, arXiv:1002.0840    
# (c) Florian Staub, 2011  
# ----------------------------------------------------------------------  
# File created at 14:50 on 5.12.2017   
# ----------------------------------------------------------------------  
 
 
from object_library import all_parameters,Parameter 
 
from function_library import complexconjugate,re,im,csc,sec,acsc,asec 
 
ZERO=Parameter(name='ZERO', 
                      nature='internal', 
                      type='real', 
                      value='0.0', 
                      texname='0') 
 
Md1 = 	 Parameter(name = 'Md1', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0.0035, 
	 texname = '\\text{Md1}', 
	 lhablock = 'MASS', 
	 lhacode = [1]) 
 
Md2 = 	 Parameter(name = 'Md2', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0.104, 
	 texname = '\\text{Md2}', 
	 lhablock = 'MASS', 
	 lhacode = [3]) 
 
Md3 = 	 Parameter(name = 'Md3', 
	 nature = 'external', 
	 type = 'real', 
	 value = 4.2, 
	 texname = '\\text{Md3}', 
	 lhablock = 'MASS', 
	 lhacode = [5]) 
 
Mu1 = 	 Parameter(name = 'Mu1', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0.0015, 
	 texname = '\\text{Mu1}', 
	 lhablock = 'MASS', 
	 lhacode = [2]) 
 
Mu2 = 	 Parameter(name = 'Mu2', 
	 nature = 'external', 
	 type = 'real', 
	 value = 1.27, 
	 texname = '\\text{Mu2}', 
	 lhablock = 'MASS', 
	 lhacode = [4]) 
 
Mu3 = 	 Parameter(name = 'Mu3', 
	 nature = 'external', 
	 type = 'real', 
	 value = 171.2, 
	 texname = '\\text{Mu3}', 
	 lhablock = 'MASS', 
	 lhacode = [6]) 
 
Wu3 = 	 Parameter(name = 'Wu3', 
	 nature = 'external', 
	 type = 'real', 
	 value = 1.51, 
	 texname = '\\text{Wu3}', 
	 lhablock = 'DECAY', 
	 lhacode = [6]) 
 
Me1 = 	 Parameter(name = 'Me1', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0.000511, 
	 texname = '\\text{Me1}', 
	 lhablock = 'MASS', 
	 lhacode = [11]) 
 
Me2 = 	 Parameter(name = 'Me2', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0.105, 
	 texname = '\\text{Me2}', 
	 lhablock = 'MASS', 
	 lhacode = [13]) 
 
Me3 = 	 Parameter(name = 'Me3', 
	 nature = 'external', 
	 type = 'real', 
	 value = 1.776, 
	 texname = '\\text{Me3}', 
	 lhablock = 'MASS', 
	 lhacode = [15]) 
 
Mnu4 = 	 Parameter(name = 'Mnu4', 
	 nature = 'external', 
	 type = 'real', 
	 value = 100., 
	 texname = '\\text{Mnu4}', 
	 lhablock = 'MASS', 
	 lhacode = [112]) 
 
Wnu4 = 	 Parameter(name = 'Wnu4', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Wnu4}', 
	 lhablock = 'DECAY', 
	 lhacode = [112]) 
 
Mnu5 = 	 Parameter(name = 'Mnu5', 
	 nature = 'external', 
	 type = 'real', 
	 value = 100., 
	 texname = '\\text{Mnu5}', 
	 lhablock = 'MASS', 
	 lhacode = [114]) 
 
Wnu5 = 	 Parameter(name = 'Wnu5', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Wnu5}', 
	 lhablock = 'DECAY', 
	 lhacode = [114]) 
 
Mnu6 = 	 Parameter(name = 'Mnu6', 
	 nature = 'external', 
	 type = 'real', 
	 value = 100., 
	 texname = '\\text{Mnu6}', 
	 lhablock = 'MASS', 
	 lhacode = [116]) 
 
Wnu6 = 	 Parameter(name = 'Wnu6', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Wnu6}', 
	 lhablock = 'DECAY', 
	 lhacode = [116]) 
 
Mh = 	 Parameter(name = 'Mh', 
	 nature = 'external', 
	 type = 'real', 
	 value = 100., 
	 texname = '\\text{Mh}', 
	 lhablock = 'MASS', 
	 lhacode = [25]) 
 
Wh = 	 Parameter(name = 'Wh', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Wh}', 
	 lhablock = 'DECAY', 
	 lhacode = [25]) 
 
MZ = 	 Parameter(name = 'MZ', 
	 nature = 'external', 
	 type = 'real', 
	 value = 91.1876, 
	 texname = '\\text{MZ}', 
	 lhablock = 'MASS', 
	 lhacode = [23]) 
 
WZ = 	 Parameter(name = 'WZ', 
	 nature = 'external', 
	 type = 'real', 
	 value = 2.4952, 
	 texname = '\\text{WZ}', 
	 lhablock = 'DECAY', 
	 lhacode = [23]) 
 
WWp = 	 Parameter(name = 'WWp', 
	 nature = 'external', 
	 type = 'real', 
	 value = 2.141, 
	 texname = '\\text{WWp}', 
	 lhablock = 'DECAY', 
	 lhacode = [24]) 
 
rYv11 = 	 Parameter(name='rYv11', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Yv11}', 
	 lhablock = 'YV', 
	 lhacode = [1, 1] ) 
 
iYv11 = 	 Parameter(name='iYv11', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Yv11}', 
	 lhablock = 'IMYV', 
	 lhacode = [1, 1] ) 
 
rYv12 = 	 Parameter(name='rYv12', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Yv12}', 
	 lhablock = 'YV', 
	 lhacode = [1, 2] ) 
 
iYv12 = 	 Parameter(name='iYv12', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Yv12}', 
	 lhablock = 'IMYV', 
	 lhacode = [1, 2] ) 
 
rYv13 = 	 Parameter(name='rYv13', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Yv13}', 
	 lhablock = 'YV', 
	 lhacode = [1, 3] ) 
 
iYv13 = 	 Parameter(name='iYv13', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Yv13}', 
	 lhablock = 'IMYV', 
	 lhacode = [1, 3] ) 
 
rYv21 = 	 Parameter(name='rYv21', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Yv21}', 
	 lhablock = 'YV', 
	 lhacode = [2, 1] ) 
 
iYv21 = 	 Parameter(name='iYv21', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Yv21}', 
	 lhablock = 'IMYV', 
	 lhacode = [2, 1] ) 
 
rYv22 = 	 Parameter(name='rYv22', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Yv22}', 
	 lhablock = 'YV', 
	 lhacode = [2, 2] ) 
 
iYv22 = 	 Parameter(name='iYv22', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Yv22}', 
	 lhablock = 'IMYV', 
	 lhacode = [2, 2] ) 
 
rYv23 = 	 Parameter(name='rYv23', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Yv23}', 
	 lhablock = 'YV', 
	 lhacode = [2, 3] ) 
 
iYv23 = 	 Parameter(name='iYv23', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Yv23}', 
	 lhablock = 'IMYV', 
	 lhacode = [2, 3] ) 
 
rYv31 = 	 Parameter(name='rYv31', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Yv31}', 
	 lhablock = 'YV', 
	 lhacode = [3, 1] ) 
 
iYv31 = 	 Parameter(name='iYv31', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Yv31}', 
	 lhablock = 'IMYV', 
	 lhacode = [3, 1] ) 
 
rYv32 = 	 Parameter(name='rYv32', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Yv32}', 
	 lhablock = 'YV', 
	 lhacode = [3, 2] ) 
 
iYv32 = 	 Parameter(name='iYv32', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Yv32}', 
	 lhablock = 'IMYV', 
	 lhacode = [3, 2] ) 
 
rYv33 = 	 Parameter(name='rYv33', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Yv33}', 
	 lhablock = 'YV', 
	 lhacode = [3, 3] ) 
 
iYv33 = 	 Parameter(name='iYv33', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Yv33}', 
	 lhablock = 'IMYV', 
	 lhacode = [3, 3] ) 
 
rZDL11 = 	 Parameter(name='rZDL11', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDL11}', 
	 lhablock = 'UDLMIX', 
	 lhacode = [1, 1] ) 
 
iZDL11 = 	 Parameter(name='iZDL11', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDL11}', 
	 lhablock = 'IMUDLMIX', 
	 lhacode = [1, 1] ) 
 
rZDL12 = 	 Parameter(name='rZDL12', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDL12}', 
	 lhablock = 'UDLMIX', 
	 lhacode = [1, 2] ) 
 
iZDL12 = 	 Parameter(name='iZDL12', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDL12}', 
	 lhablock = 'IMUDLMIX', 
	 lhacode = [1, 2] ) 
 
rZDL13 = 	 Parameter(name='rZDL13', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDL13}', 
	 lhablock = 'UDLMIX', 
	 lhacode = [1, 3] ) 
 
iZDL13 = 	 Parameter(name='iZDL13', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDL13}', 
	 lhablock = 'IMUDLMIX', 
	 lhacode = [1, 3] ) 
 
rZDL21 = 	 Parameter(name='rZDL21', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDL21}', 
	 lhablock = 'UDLMIX', 
	 lhacode = [2, 1] ) 
 
iZDL21 = 	 Parameter(name='iZDL21', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDL21}', 
	 lhablock = 'IMUDLMIX', 
	 lhacode = [2, 1] ) 
 
rZDL22 = 	 Parameter(name='rZDL22', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDL22}', 
	 lhablock = 'UDLMIX', 
	 lhacode = [2, 2] ) 
 
iZDL22 = 	 Parameter(name='iZDL22', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDL22}', 
	 lhablock = 'IMUDLMIX', 
	 lhacode = [2, 2] ) 
 
rZDL23 = 	 Parameter(name='rZDL23', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDL23}', 
	 lhablock = 'UDLMIX', 
	 lhacode = [2, 3] ) 
 
iZDL23 = 	 Parameter(name='iZDL23', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDL23}', 
	 lhablock = 'IMUDLMIX', 
	 lhacode = [2, 3] ) 
 
rZDL31 = 	 Parameter(name='rZDL31', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDL31}', 
	 lhablock = 'UDLMIX', 
	 lhacode = [3, 1] ) 
 
iZDL31 = 	 Parameter(name='iZDL31', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDL31}', 
	 lhablock = 'IMUDLMIX', 
	 lhacode = [3, 1] ) 
 
rZDL32 = 	 Parameter(name='rZDL32', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDL32}', 
	 lhablock = 'UDLMIX', 
	 lhacode = [3, 2] ) 
 
iZDL32 = 	 Parameter(name='iZDL32', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDL32}', 
	 lhablock = 'IMUDLMIX', 
	 lhacode = [3, 2] ) 
 
rZDL33 = 	 Parameter(name='rZDL33', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDL33}', 
	 lhablock = 'UDLMIX', 
	 lhacode = [3, 3] ) 
 
iZDL33 = 	 Parameter(name='iZDL33', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDL33}', 
	 lhablock = 'IMUDLMIX', 
	 lhacode = [3, 3] ) 
 
rZDR11 = 	 Parameter(name='rZDR11', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDR11}', 
	 lhablock = 'UDRMIX', 
	 lhacode = [1, 1] ) 
 
iZDR11 = 	 Parameter(name='iZDR11', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDR11}', 
	 lhablock = 'IMUDRMIX', 
	 lhacode = [1, 1] ) 
 
rZDR12 = 	 Parameter(name='rZDR12', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDR12}', 
	 lhablock = 'UDRMIX', 
	 lhacode = [1, 2] ) 
 
iZDR12 = 	 Parameter(name='iZDR12', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDR12}', 
	 lhablock = 'IMUDRMIX', 
	 lhacode = [1, 2] ) 
 
rZDR13 = 	 Parameter(name='rZDR13', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDR13}', 
	 lhablock = 'UDRMIX', 
	 lhacode = [1, 3] ) 
 
iZDR13 = 	 Parameter(name='iZDR13', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDR13}', 
	 lhablock = 'IMUDRMIX', 
	 lhacode = [1, 3] ) 
 
rZDR21 = 	 Parameter(name='rZDR21', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDR21}', 
	 lhablock = 'UDRMIX', 
	 lhacode = [2, 1] ) 
 
iZDR21 = 	 Parameter(name='iZDR21', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDR21}', 
	 lhablock = 'IMUDRMIX', 
	 lhacode = [2, 1] ) 
 
rZDR22 = 	 Parameter(name='rZDR22', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDR22}', 
	 lhablock = 'UDRMIX', 
	 lhacode = [2, 2] ) 
 
iZDR22 = 	 Parameter(name='iZDR22', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDR22}', 
	 lhablock = 'IMUDRMIX', 
	 lhacode = [2, 2] ) 
 
rZDR23 = 	 Parameter(name='rZDR23', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDR23}', 
	 lhablock = 'UDRMIX', 
	 lhacode = [2, 3] ) 
 
iZDR23 = 	 Parameter(name='iZDR23', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDR23}', 
	 lhablock = 'IMUDRMIX', 
	 lhacode = [2, 3] ) 
 
rZDR31 = 	 Parameter(name='rZDR31', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDR31}', 
	 lhablock = 'UDRMIX', 
	 lhacode = [3, 1] ) 
 
iZDR31 = 	 Parameter(name='iZDR31', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDR31}', 
	 lhablock = 'IMUDRMIX', 
	 lhacode = [3, 1] ) 
 
rZDR32 = 	 Parameter(name='rZDR32', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDR32}', 
	 lhablock = 'UDRMIX', 
	 lhacode = [3, 2] ) 
 
iZDR32 = 	 Parameter(name='iZDR32', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDR32}', 
	 lhablock = 'IMUDRMIX', 
	 lhacode = [3, 2] ) 
 
rZDR33 = 	 Parameter(name='rZDR33', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDR33}', 
	 lhablock = 'UDRMIX', 
	 lhacode = [3, 3] ) 
 
iZDR33 = 	 Parameter(name='iZDR33', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZDR33}', 
	 lhablock = 'IMUDRMIX', 
	 lhacode = [3, 3] ) 
 
rZUL11 = 	 Parameter(name='rZUL11', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUL11}', 
	 lhablock = 'UULMIX', 
	 lhacode = [1, 1] ) 
 
iZUL11 = 	 Parameter(name='iZUL11', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUL11}', 
	 lhablock = 'IMUULMIX', 
	 lhacode = [1, 1] ) 
 
rZUL12 = 	 Parameter(name='rZUL12', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUL12}', 
	 lhablock = 'UULMIX', 
	 lhacode = [1, 2] ) 
 
iZUL12 = 	 Parameter(name='iZUL12', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUL12}', 
	 lhablock = 'IMUULMIX', 
	 lhacode = [1, 2] ) 
 
rZUL13 = 	 Parameter(name='rZUL13', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUL13}', 
	 lhablock = 'UULMIX', 
	 lhacode = [1, 3] ) 
 
iZUL13 = 	 Parameter(name='iZUL13', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUL13}', 
	 lhablock = 'IMUULMIX', 
	 lhacode = [1, 3] ) 
 
rZUL21 = 	 Parameter(name='rZUL21', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUL21}', 
	 lhablock = 'UULMIX', 
	 lhacode = [2, 1] ) 
 
iZUL21 = 	 Parameter(name='iZUL21', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUL21}', 
	 lhablock = 'IMUULMIX', 
	 lhacode = [2, 1] ) 
 
rZUL22 = 	 Parameter(name='rZUL22', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUL22}', 
	 lhablock = 'UULMIX', 
	 lhacode = [2, 2] ) 
 
iZUL22 = 	 Parameter(name='iZUL22', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUL22}', 
	 lhablock = 'IMUULMIX', 
	 lhacode = [2, 2] ) 
 
rZUL23 = 	 Parameter(name='rZUL23', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUL23}', 
	 lhablock = 'UULMIX', 
	 lhacode = [2, 3] ) 
 
iZUL23 = 	 Parameter(name='iZUL23', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUL23}', 
	 lhablock = 'IMUULMIX', 
	 lhacode = [2, 3] ) 
 
rZUL31 = 	 Parameter(name='rZUL31', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUL31}', 
	 lhablock = 'UULMIX', 
	 lhacode = [3, 1] ) 
 
iZUL31 = 	 Parameter(name='iZUL31', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUL31}', 
	 lhablock = 'IMUULMIX', 
	 lhacode = [3, 1] ) 
 
rZUL32 = 	 Parameter(name='rZUL32', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUL32}', 
	 lhablock = 'UULMIX', 
	 lhacode = [3, 2] ) 
 
iZUL32 = 	 Parameter(name='iZUL32', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUL32}', 
	 lhablock = 'IMUULMIX', 
	 lhacode = [3, 2] ) 
 
rZUL33 = 	 Parameter(name='rZUL33', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUL33}', 
	 lhablock = 'UULMIX', 
	 lhacode = [3, 3] ) 
 
iZUL33 = 	 Parameter(name='iZUL33', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUL33}', 
	 lhablock = 'IMUULMIX', 
	 lhacode = [3, 3] ) 
 
rZUR11 = 	 Parameter(name='rZUR11', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUR11}', 
	 lhablock = 'UURMIX', 
	 lhacode = [1, 1] ) 
 
iZUR11 = 	 Parameter(name='iZUR11', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUR11}', 
	 lhablock = 'IMUURMIX', 
	 lhacode = [1, 1] ) 
 
rZUR12 = 	 Parameter(name='rZUR12', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUR12}', 
	 lhablock = 'UURMIX', 
	 lhacode = [1, 2] ) 
 
iZUR12 = 	 Parameter(name='iZUR12', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUR12}', 
	 lhablock = 'IMUURMIX', 
	 lhacode = [1, 2] ) 
 
rZUR13 = 	 Parameter(name='rZUR13', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUR13}', 
	 lhablock = 'UURMIX', 
	 lhacode = [1, 3] ) 
 
iZUR13 = 	 Parameter(name='iZUR13', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUR13}', 
	 lhablock = 'IMUURMIX', 
	 lhacode = [1, 3] ) 
 
rZUR21 = 	 Parameter(name='rZUR21', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUR21}', 
	 lhablock = 'UURMIX', 
	 lhacode = [2, 1] ) 
 
iZUR21 = 	 Parameter(name='iZUR21', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUR21}', 
	 lhablock = 'IMUURMIX', 
	 lhacode = [2, 1] ) 
 
rZUR22 = 	 Parameter(name='rZUR22', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUR22}', 
	 lhablock = 'UURMIX', 
	 lhacode = [2, 2] ) 
 
iZUR22 = 	 Parameter(name='iZUR22', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUR22}', 
	 lhablock = 'IMUURMIX', 
	 lhacode = [2, 2] ) 
 
rZUR23 = 	 Parameter(name='rZUR23', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUR23}', 
	 lhablock = 'UURMIX', 
	 lhacode = [2, 3] ) 
 
iZUR23 = 	 Parameter(name='iZUR23', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUR23}', 
	 lhablock = 'IMUURMIX', 
	 lhacode = [2, 3] ) 
 
rZUR31 = 	 Parameter(name='rZUR31', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUR31}', 
	 lhablock = 'UURMIX', 
	 lhacode = [3, 1] ) 
 
iZUR31 = 	 Parameter(name='iZUR31', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUR31}', 
	 lhablock = 'IMUURMIX', 
	 lhacode = [3, 1] ) 
 
rZUR32 = 	 Parameter(name='rZUR32', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUR32}', 
	 lhablock = 'UURMIX', 
	 lhacode = [3, 2] ) 
 
iZUR32 = 	 Parameter(name='iZUR32', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUR32}', 
	 lhablock = 'IMUURMIX', 
	 lhacode = [3, 2] ) 
 
rZUR33 = 	 Parameter(name='rZUR33', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUR33}', 
	 lhablock = 'UURMIX', 
	 lhacode = [3, 3] ) 
 
iZUR33 = 	 Parameter(name='iZUR33', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZUR33}', 
	 lhablock = 'IMUURMIX', 
	 lhacode = [3, 3] ) 
 
rZEL11 = 	 Parameter(name='rZEL11', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZEL11}', 
	 lhablock = 'UELMIX', 
	 lhacode = [1, 1] ) 
 
iZEL11 = 	 Parameter(name='iZEL11', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZEL11}', 
	 lhablock = 'IMUELMIX', 
	 lhacode = [1, 1] ) 
 
rZEL12 = 	 Parameter(name='rZEL12', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZEL12}', 
	 lhablock = 'UELMIX', 
	 lhacode = [1, 2] ) 
 
iZEL12 = 	 Parameter(name='iZEL12', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZEL12}', 
	 lhablock = 'IMUELMIX', 
	 lhacode = [1, 2] ) 
 
rZEL13 = 	 Parameter(name='rZEL13', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZEL13}', 
	 lhablock = 'UELMIX', 
	 lhacode = [1, 3] ) 
 
iZEL13 = 	 Parameter(name='iZEL13', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZEL13}', 
	 lhablock = 'IMUELMIX', 
	 lhacode = [1, 3] ) 
 
rZEL21 = 	 Parameter(name='rZEL21', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZEL21}', 
	 lhablock = 'UELMIX', 
	 lhacode = [2, 1] ) 
 
iZEL21 = 	 Parameter(name='iZEL21', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZEL21}', 
	 lhablock = 'IMUELMIX', 
	 lhacode = [2, 1] ) 
 
rZEL22 = 	 Parameter(name='rZEL22', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZEL22}', 
	 lhablock = 'UELMIX', 
	 lhacode = [2, 2] ) 
 
iZEL22 = 	 Parameter(name='iZEL22', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZEL22}', 
	 lhablock = 'IMUELMIX', 
	 lhacode = [2, 2] ) 
 
rZEL23 = 	 Parameter(name='rZEL23', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZEL23}', 
	 lhablock = 'UELMIX', 
	 lhacode = [2, 3] ) 
 
iZEL23 = 	 Parameter(name='iZEL23', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZEL23}', 
	 lhablock = 'IMUELMIX', 
	 lhacode = [2, 3] ) 
 
rZEL31 = 	 Parameter(name='rZEL31', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZEL31}', 
	 lhablock = 'UELMIX', 
	 lhacode = [3, 1] ) 
 
iZEL31 = 	 Parameter(name='iZEL31', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZEL31}', 
	 lhablock = 'IMUELMIX', 
	 lhacode = [3, 1] ) 
 
rZEL32 = 	 Parameter(name='rZEL32', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZEL32}', 
	 lhablock = 'UELMIX', 
	 lhacode = [3, 2] ) 
 
iZEL32 = 	 Parameter(name='iZEL32', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZEL32}', 
	 lhablock = 'IMUELMIX', 
	 lhacode = [3, 2] ) 
 
rZEL33 = 	 Parameter(name='rZEL33', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZEL33}', 
	 lhablock = 'UELMIX', 
	 lhacode = [3, 3] ) 
 
iZEL33 = 	 Parameter(name='iZEL33', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZEL33}', 
	 lhablock = 'IMUELMIX', 
	 lhacode = [3, 3] ) 
 
rZER11 = 	 Parameter(name='rZER11', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZER11}', 
	 lhablock = 'UERMIX', 
	 lhacode = [1, 1] ) 
 
iZER11 = 	 Parameter(name='iZER11', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZER11}', 
	 lhablock = 'IMUERMIX', 
	 lhacode = [1, 1] ) 
 
rZER12 = 	 Parameter(name='rZER12', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZER12}', 
	 lhablock = 'UERMIX', 
	 lhacode = [1, 2] ) 
 
iZER12 = 	 Parameter(name='iZER12', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZER12}', 
	 lhablock = 'IMUERMIX', 
	 lhacode = [1, 2] ) 
 
rZER13 = 	 Parameter(name='rZER13', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZER13}', 
	 lhablock = 'UERMIX', 
	 lhacode = [1, 3] ) 
 
iZER13 = 	 Parameter(name='iZER13', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZER13}', 
	 lhablock = 'IMUERMIX', 
	 lhacode = [1, 3] ) 
 
rZER21 = 	 Parameter(name='rZER21', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZER21}', 
	 lhablock = 'UERMIX', 
	 lhacode = [2, 1] ) 
 
iZER21 = 	 Parameter(name='iZER21', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZER21}', 
	 lhablock = 'IMUERMIX', 
	 lhacode = [2, 1] ) 
 
rZER22 = 	 Parameter(name='rZER22', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZER22}', 
	 lhablock = 'UERMIX', 
	 lhacode = [2, 2] ) 
 
iZER22 = 	 Parameter(name='iZER22', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZER22}', 
	 lhablock = 'IMUERMIX', 
	 lhacode = [2, 2] ) 
 
rZER23 = 	 Parameter(name='rZER23', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZER23}', 
	 lhablock = 'UERMIX', 
	 lhacode = [2, 3] ) 
 
iZER23 = 	 Parameter(name='iZER23', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZER23}', 
	 lhablock = 'IMUERMIX', 
	 lhacode = [2, 3] ) 
 
rZER31 = 	 Parameter(name='rZER31', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZER31}', 
	 lhablock = 'UERMIX', 
	 lhacode = [3, 1] ) 
 
iZER31 = 	 Parameter(name='iZER31', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZER31}', 
	 lhablock = 'IMUERMIX', 
	 lhacode = [3, 1] ) 
 
rZER32 = 	 Parameter(name='rZER32', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZER32}', 
	 lhablock = 'UERMIX', 
	 lhacode = [3, 2] ) 
 
iZER32 = 	 Parameter(name='iZER32', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZER32}', 
	 lhablock = 'IMUERMIX', 
	 lhacode = [3, 2] ) 
 
rZER33 = 	 Parameter(name='rZER33', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZER33}', 
	 lhablock = 'UERMIX', 
	 lhacode = [3, 3] ) 
 
iZER33 = 	 Parameter(name='iZER33', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{ZER33}', 
	 lhablock = 'IMUERMIX', 
	 lhacode = [3, 3] ) 
 
rVv11 = 	 Parameter(name='rVv11', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv11}', 
	 lhablock = 'VV', 
	 lhacode = [1, 1] ) 
 
iVv11 = 	 Parameter(name='iVv11', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv11}', 
	 lhablock = 'IMVV', 
	 lhacode = [1, 1] ) 
 
rVv12 = 	 Parameter(name='rVv12', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv12}', 
	 lhablock = 'VV', 
	 lhacode = [1, 2] ) 
 
iVv12 = 	 Parameter(name='iVv12', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv12}', 
	 lhablock = 'IMVV', 
	 lhacode = [1, 2] ) 
 
rVv13 = 	 Parameter(name='rVv13', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv13}', 
	 lhablock = 'VV', 
	 lhacode = [1, 3] ) 
 
iVv13 = 	 Parameter(name='iVv13', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv13}', 
	 lhablock = 'IMVV', 
	 lhacode = [1, 3] ) 
 
rVv14 = 	 Parameter(name='rVv14', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv14}', 
	 lhablock = 'VV', 
	 lhacode = [1, 4] ) 
 
iVv14 = 	 Parameter(name='iVv14', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv14}', 
	 lhablock = 'IMVV', 
	 lhacode = [1, 4] ) 
 
rVv15 = 	 Parameter(name='rVv15', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv15}', 
	 lhablock = 'VV', 
	 lhacode = [1, 5] ) 
 
iVv15 = 	 Parameter(name='iVv15', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv15}', 
	 lhablock = 'IMVV', 
	 lhacode = [1, 5] ) 
 
rVv16 = 	 Parameter(name='rVv16', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv16}', 
	 lhablock = 'VV', 
	 lhacode = [1, 6] ) 
 
iVv16 = 	 Parameter(name='iVv16', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv16}', 
	 lhablock = 'IMVV', 
	 lhacode = [1, 6] ) 
 
rVv21 = 	 Parameter(name='rVv21', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv21}', 
	 lhablock = 'VV', 
	 lhacode = [2, 1] ) 
 
iVv21 = 	 Parameter(name='iVv21', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv21}', 
	 lhablock = 'IMVV', 
	 lhacode = [2, 1] ) 
 
rVv22 = 	 Parameter(name='rVv22', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv22}', 
	 lhablock = 'VV', 
	 lhacode = [2, 2] ) 
 
iVv22 = 	 Parameter(name='iVv22', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv22}', 
	 lhablock = 'IMVV', 
	 lhacode = [2, 2] ) 
 
rVv23 = 	 Parameter(name='rVv23', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv23}', 
	 lhablock = 'VV', 
	 lhacode = [2, 3] ) 
 
iVv23 = 	 Parameter(name='iVv23', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv23}', 
	 lhablock = 'IMVV', 
	 lhacode = [2, 3] ) 
 
rVv24 = 	 Parameter(name='rVv24', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv24}', 
	 lhablock = 'VV', 
	 lhacode = [2, 4] ) 
 
iVv24 = 	 Parameter(name='iVv24', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv24}', 
	 lhablock = 'IMVV', 
	 lhacode = [2, 4] ) 
 
rVv25 = 	 Parameter(name='rVv25', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv25}', 
	 lhablock = 'VV', 
	 lhacode = [2, 5] ) 
 
iVv25 = 	 Parameter(name='iVv25', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv25}', 
	 lhablock = 'IMVV', 
	 lhacode = [2, 5] ) 
 
rVv26 = 	 Parameter(name='rVv26', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv26}', 
	 lhablock = 'VV', 
	 lhacode = [2, 6] ) 
 
iVv26 = 	 Parameter(name='iVv26', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv26}', 
	 lhablock = 'IMVV', 
	 lhacode = [2, 6] ) 
 
rVv31 = 	 Parameter(name='rVv31', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv31}', 
	 lhablock = 'VV', 
	 lhacode = [3, 1] ) 
 
iVv31 = 	 Parameter(name='iVv31', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv31}', 
	 lhablock = 'IMVV', 
	 lhacode = [3, 1] ) 
 
rVv32 = 	 Parameter(name='rVv32', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv32}', 
	 lhablock = 'VV', 
	 lhacode = [3, 2] ) 
 
iVv32 = 	 Parameter(name='iVv32', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv32}', 
	 lhablock = 'IMVV', 
	 lhacode = [3, 2] ) 
 
rVv33 = 	 Parameter(name='rVv33', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv33}', 
	 lhablock = 'VV', 
	 lhacode = [3, 3] ) 
 
iVv33 = 	 Parameter(name='iVv33', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv33}', 
	 lhablock = 'IMVV', 
	 lhacode = [3, 3] ) 
 
rVv34 = 	 Parameter(name='rVv34', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv34}', 
	 lhablock = 'VV', 
	 lhacode = [3, 4] ) 
 
iVv34 = 	 Parameter(name='iVv34', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv34}', 
	 lhablock = 'IMVV', 
	 lhacode = [3, 4] ) 
 
rVv35 = 	 Parameter(name='rVv35', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv35}', 
	 lhablock = 'VV', 
	 lhacode = [3, 5] ) 
 
iVv35 = 	 Parameter(name='iVv35', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv35}', 
	 lhablock = 'IMVV', 
	 lhacode = [3, 5] ) 
 
rVv36 = 	 Parameter(name='rVv36', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv36}', 
	 lhablock = 'VV', 
	 lhacode = [3, 6] ) 
 
iVv36 = 	 Parameter(name='iVv36', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv36}', 
	 lhablock = 'IMVV', 
	 lhacode = [3, 6] ) 
 
rVv41 = 	 Parameter(name='rVv41', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv41}', 
	 lhablock = 'VV', 
	 lhacode = [4, 1] ) 
 
iVv41 = 	 Parameter(name='iVv41', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv41}', 
	 lhablock = 'IMVV', 
	 lhacode = [4, 1] ) 
 
rVv42 = 	 Parameter(name='rVv42', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv42}', 
	 lhablock = 'VV', 
	 lhacode = [4, 2] ) 
 
iVv42 = 	 Parameter(name='iVv42', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv42}', 
	 lhablock = 'IMVV', 
	 lhacode = [4, 2] ) 
 
rVv43 = 	 Parameter(name='rVv43', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv43}', 
	 lhablock = 'VV', 
	 lhacode = [4, 3] ) 
 
iVv43 = 	 Parameter(name='iVv43', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv43}', 
	 lhablock = 'IMVV', 
	 lhacode = [4, 3] ) 
 
rVv44 = 	 Parameter(name='rVv44', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv44}', 
	 lhablock = 'VV', 
	 lhacode = [4, 4] ) 
 
iVv44 = 	 Parameter(name='iVv44', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv44}', 
	 lhablock = 'IMVV', 
	 lhacode = [4, 4] ) 
 
rVv45 = 	 Parameter(name='rVv45', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv45}', 
	 lhablock = 'VV', 
	 lhacode = [4, 5] ) 
 
iVv45 = 	 Parameter(name='iVv45', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv45}', 
	 lhablock = 'IMVV', 
	 lhacode = [4, 5] ) 
 
rVv46 = 	 Parameter(name='rVv46', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv46}', 
	 lhablock = 'VV', 
	 lhacode = [4, 6] ) 
 
iVv46 = 	 Parameter(name='iVv46', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv46}', 
	 lhablock = 'IMVV', 
	 lhacode = [4, 6] ) 
 
rVv51 = 	 Parameter(name='rVv51', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv51}', 
	 lhablock = 'VV', 
	 lhacode = [5, 1] ) 
 
iVv51 = 	 Parameter(name='iVv51', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv51}', 
	 lhablock = 'IMVV', 
	 lhacode = [5, 1] ) 
 
rVv52 = 	 Parameter(name='rVv52', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv52}', 
	 lhablock = 'VV', 
	 lhacode = [5, 2] ) 
 
iVv52 = 	 Parameter(name='iVv52', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv52}', 
	 lhablock = 'IMVV', 
	 lhacode = [5, 2] ) 
 
rVv53 = 	 Parameter(name='rVv53', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv53}', 
	 lhablock = 'VV', 
	 lhacode = [5, 3] ) 
 
iVv53 = 	 Parameter(name='iVv53', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv53}', 
	 lhablock = 'IMVV', 
	 lhacode = [5, 3] ) 
 
rVv54 = 	 Parameter(name='rVv54', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv54}', 
	 lhablock = 'VV', 
	 lhacode = [5, 4] ) 
 
iVv54 = 	 Parameter(name='iVv54', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv54}', 
	 lhablock = 'IMVV', 
	 lhacode = [5, 4] ) 
 
rVv55 = 	 Parameter(name='rVv55', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv55}', 
	 lhablock = 'VV', 
	 lhacode = [5, 5] ) 
 
iVv55 = 	 Parameter(name='iVv55', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv55}', 
	 lhablock = 'IMVV', 
	 lhacode = [5, 5] ) 
 
rVv56 = 	 Parameter(name='rVv56', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv56}', 
	 lhablock = 'VV', 
	 lhacode = [5, 6] ) 
 
iVv56 = 	 Parameter(name='iVv56', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv56}', 
	 lhablock = 'IMVV', 
	 lhacode = [5, 6] ) 
 
rVv61 = 	 Parameter(name='rVv61', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv61}', 
	 lhablock = 'VV', 
	 lhacode = [6, 1] ) 
 
iVv61 = 	 Parameter(name='iVv61', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv61}', 
	 lhablock = 'IMVV', 
	 lhacode = [6, 1] ) 
 
rVv62 = 	 Parameter(name='rVv62', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv62}', 
	 lhablock = 'VV', 
	 lhacode = [6, 2] ) 
 
iVv62 = 	 Parameter(name='iVv62', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv62}', 
	 lhablock = 'IMVV', 
	 lhacode = [6, 2] ) 
 
rVv63 = 	 Parameter(name='rVv63', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv63}', 
	 lhablock = 'VV', 
	 lhacode = [6, 3] ) 
 
iVv63 = 	 Parameter(name='iVv63', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv63}', 
	 lhablock = 'IMVV', 
	 lhacode = [6, 3] ) 
 
rVv64 = 	 Parameter(name='rVv64', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv64}', 
	 lhablock = 'VV', 
	 lhacode = [6, 4] ) 
 
iVv64 = 	 Parameter(name='iVv64', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv64}', 
	 lhablock = 'IMVV', 
	 lhacode = [6, 4] ) 
 
rVv65 = 	 Parameter(name='rVv65', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv65}', 
	 lhablock = 'VV', 
	 lhacode = [6, 5] ) 
 
iVv65 = 	 Parameter(name='iVv65', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv65}', 
	 lhablock = 'IMVV', 
	 lhacode = [6, 5] ) 
 
rVv66 = 	 Parameter(name='rVv66', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv66}', 
	 lhablock = 'VV', 
	 lhacode = [6, 6] ) 
 
iVv66 = 	 Parameter(name='iVv66', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{Vv66}', 
	 lhablock = 'IMVV', 
	 lhacode = [6, 6] ) 
 
aS = 	 Parameter(name='aS', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0.119, 
	 texname = '\\text{aS}', 
	 lhablock = 'SMINPUTS', 
	 lhacode = [3] ) 
 
aEWM1 = 	 Parameter(name='aEWM1', 
	 nature = 'external', 
	 type = 'real', 
	 value = 137.035999679, 
	 texname = '\\text{aEWM1}', 
	 lhablock = 'SMINPUTS', 
	 lhacode = [1] ) 
 
Gf = 	 Parameter(name='Gf', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0.0000116639, 
	 texname = '\\text{Gf}', 
	 lhablock = 'SMINPUTS', 
	 lhacode = [2] ) 
 
Yv11 = 	 Parameter(name='Yv11', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rYv11 + complex(0,1)*iYv11', 
	 texname = '\\text{Yv11}' ) 
 
Yv12 = 	 Parameter(name='Yv12', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rYv12 + complex(0,1)*iYv12', 
	 texname = '\\text{Yv12}' ) 
 
Yv13 = 	 Parameter(name='Yv13', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rYv13 + complex(0,1)*iYv13', 
	 texname = '\\text{Yv13}' ) 
 
Yv21 = 	 Parameter(name='Yv21', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rYv21 + complex(0,1)*iYv21', 
	 texname = '\\text{Yv21}' ) 
 
Yv22 = 	 Parameter(name='Yv22', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rYv22 + complex(0,1)*iYv22', 
	 texname = '\\text{Yv22}' ) 
 
Yv23 = 	 Parameter(name='Yv23', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rYv23 + complex(0,1)*iYv23', 
	 texname = '\\text{Yv23}' ) 
 
Yv31 = 	 Parameter(name='Yv31', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rYv31 + complex(0,1)*iYv31', 
	 texname = '\\text{Yv31}' ) 
 
Yv32 = 	 Parameter(name='Yv32', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rYv32 + complex(0,1)*iYv32', 
	 texname = '\\text{Yv32}' ) 
 
Yv33 = 	 Parameter(name='Yv33', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rYv33 + complex(0,1)*iYv33', 
	 texname = '\\text{Yv33}' ) 
 
ZDL11 = 	 Parameter(name='ZDL11', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZDL11 + complex(0,1)*iZDL11', 
	 texname = '\\text{ZDL11}' ) 
 
ZDL12 = 	 Parameter(name='ZDL12', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZDL12 + complex(0,1)*iZDL12', 
	 texname = '\\text{ZDL12}' ) 
 
ZDL13 = 	 Parameter(name='ZDL13', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZDL13 + complex(0,1)*iZDL13', 
	 texname = '\\text{ZDL13}' ) 
 
ZDL21 = 	 Parameter(name='ZDL21', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZDL21 + complex(0,1)*iZDL21', 
	 texname = '\\text{ZDL21}' ) 
 
ZDL22 = 	 Parameter(name='ZDL22', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZDL22 + complex(0,1)*iZDL22', 
	 texname = '\\text{ZDL22}' ) 
 
ZDL23 = 	 Parameter(name='ZDL23', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZDL23 + complex(0,1)*iZDL23', 
	 texname = '\\text{ZDL23}' ) 
 
ZDL31 = 	 Parameter(name='ZDL31', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZDL31 + complex(0,1)*iZDL31', 
	 texname = '\\text{ZDL31}' ) 
 
ZDL32 = 	 Parameter(name='ZDL32', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZDL32 + complex(0,1)*iZDL32', 
	 texname = '\\text{ZDL32}' ) 
 
ZDL33 = 	 Parameter(name='ZDL33', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZDL33 + complex(0,1)*iZDL33', 
	 texname = '\\text{ZDL33}' ) 
 
ZDR11 = 	 Parameter(name='ZDR11', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZDR11 + complex(0,1)*iZDR11', 
	 texname = '\\text{ZDR11}' ) 
 
ZDR12 = 	 Parameter(name='ZDR12', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZDR12 + complex(0,1)*iZDR12', 
	 texname = '\\text{ZDR12}' ) 
 
ZDR13 = 	 Parameter(name='ZDR13', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZDR13 + complex(0,1)*iZDR13', 
	 texname = '\\text{ZDR13}' ) 
 
ZDR21 = 	 Parameter(name='ZDR21', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZDR21 + complex(0,1)*iZDR21', 
	 texname = '\\text{ZDR21}' ) 
 
ZDR22 = 	 Parameter(name='ZDR22', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZDR22 + complex(0,1)*iZDR22', 
	 texname = '\\text{ZDR22}' ) 
 
ZDR23 = 	 Parameter(name='ZDR23', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZDR23 + complex(0,1)*iZDR23', 
	 texname = '\\text{ZDR23}' ) 
 
ZDR31 = 	 Parameter(name='ZDR31', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZDR31 + complex(0,1)*iZDR31', 
	 texname = '\\text{ZDR31}' ) 
 
ZDR32 = 	 Parameter(name='ZDR32', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZDR32 + complex(0,1)*iZDR32', 
	 texname = '\\text{ZDR32}' ) 
 
ZDR33 = 	 Parameter(name='ZDR33', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZDR33 + complex(0,1)*iZDR33', 
	 texname = '\\text{ZDR33}' ) 
 
ZUL11 = 	 Parameter(name='ZUL11', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZUL11 + complex(0,1)*iZUL11', 
	 texname = '\\text{ZUL11}' ) 
 
ZUL12 = 	 Parameter(name='ZUL12', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZUL12 + complex(0,1)*iZUL12', 
	 texname = '\\text{ZUL12}' ) 
 
ZUL13 = 	 Parameter(name='ZUL13', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZUL13 + complex(0,1)*iZUL13', 
	 texname = '\\text{ZUL13}' ) 
 
ZUL21 = 	 Parameter(name='ZUL21', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZUL21 + complex(0,1)*iZUL21', 
	 texname = '\\text{ZUL21}' ) 
 
ZUL22 = 	 Parameter(name='ZUL22', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZUL22 + complex(0,1)*iZUL22', 
	 texname = '\\text{ZUL22}' ) 
 
ZUL23 = 	 Parameter(name='ZUL23', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZUL23 + complex(0,1)*iZUL23', 
	 texname = '\\text{ZUL23}' ) 
 
ZUL31 = 	 Parameter(name='ZUL31', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZUL31 + complex(0,1)*iZUL31', 
	 texname = '\\text{ZUL31}' ) 
 
ZUL32 = 	 Parameter(name='ZUL32', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZUL32 + complex(0,1)*iZUL32', 
	 texname = '\\text{ZUL32}' ) 
 
ZUL33 = 	 Parameter(name='ZUL33', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZUL33 + complex(0,1)*iZUL33', 
	 texname = '\\text{ZUL33}' ) 
 
ZUR11 = 	 Parameter(name='ZUR11', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZUR11 + complex(0,1)*iZUR11', 
	 texname = '\\text{ZUR11}' ) 
 
ZUR12 = 	 Parameter(name='ZUR12', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZUR12 + complex(0,1)*iZUR12', 
	 texname = '\\text{ZUR12}' ) 
 
ZUR13 = 	 Parameter(name='ZUR13', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZUR13 + complex(0,1)*iZUR13', 
	 texname = '\\text{ZUR13}' ) 
 
ZUR21 = 	 Parameter(name='ZUR21', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZUR21 + complex(0,1)*iZUR21', 
	 texname = '\\text{ZUR21}' ) 
 
ZUR22 = 	 Parameter(name='ZUR22', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZUR22 + complex(0,1)*iZUR22', 
	 texname = '\\text{ZUR22}' ) 
 
ZUR23 = 	 Parameter(name='ZUR23', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZUR23 + complex(0,1)*iZUR23', 
	 texname = '\\text{ZUR23}' ) 
 
ZUR31 = 	 Parameter(name='ZUR31', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZUR31 + complex(0,1)*iZUR31', 
	 texname = '\\text{ZUR31}' ) 
 
ZUR32 = 	 Parameter(name='ZUR32', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZUR32 + complex(0,1)*iZUR32', 
	 texname = '\\text{ZUR32}' ) 
 
ZUR33 = 	 Parameter(name='ZUR33', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZUR33 + complex(0,1)*iZUR33', 
	 texname = '\\text{ZUR33}' ) 
 
ZEL11 = 	 Parameter(name='ZEL11', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZEL11 + complex(0,1)*iZEL11', 
	 texname = '\\text{ZEL11}' ) 
 
ZEL12 = 	 Parameter(name='ZEL12', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZEL12 + complex(0,1)*iZEL12', 
	 texname = '\\text{ZEL12}' ) 
 
ZEL13 = 	 Parameter(name='ZEL13', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZEL13 + complex(0,1)*iZEL13', 
	 texname = '\\text{ZEL13}' ) 
 
ZEL21 = 	 Parameter(name='ZEL21', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZEL21 + complex(0,1)*iZEL21', 
	 texname = '\\text{ZEL21}' ) 
 
ZEL22 = 	 Parameter(name='ZEL22', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZEL22 + complex(0,1)*iZEL22', 
	 texname = '\\text{ZEL22}' ) 
 
ZEL23 = 	 Parameter(name='ZEL23', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZEL23 + complex(0,1)*iZEL23', 
	 texname = '\\text{ZEL23}' ) 
 
ZEL31 = 	 Parameter(name='ZEL31', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZEL31 + complex(0,1)*iZEL31', 
	 texname = '\\text{ZEL31}' ) 
 
ZEL32 = 	 Parameter(name='ZEL32', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZEL32 + complex(0,1)*iZEL32', 
	 texname = '\\text{ZEL32}' ) 
 
ZEL33 = 	 Parameter(name='ZEL33', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZEL33 + complex(0,1)*iZEL33', 
	 texname = '\\text{ZEL33}' ) 
 
ZER11 = 	 Parameter(name='ZER11', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZER11 + complex(0,1)*iZER11', 
	 texname = '\\text{ZER11}' ) 
 
ZER12 = 	 Parameter(name='ZER12', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZER12 + complex(0,1)*iZER12', 
	 texname = '\\text{ZER12}' ) 
 
ZER13 = 	 Parameter(name='ZER13', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZER13 + complex(0,1)*iZER13', 
	 texname = '\\text{ZER13}' ) 
 
ZER21 = 	 Parameter(name='ZER21', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZER21 + complex(0,1)*iZER21', 
	 texname = '\\text{ZER21}' ) 
 
ZER22 = 	 Parameter(name='ZER22', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZER22 + complex(0,1)*iZER22', 
	 texname = '\\text{ZER22}' ) 
 
ZER23 = 	 Parameter(name='ZER23', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZER23 + complex(0,1)*iZER23', 
	 texname = '\\text{ZER23}' ) 
 
ZER31 = 	 Parameter(name='ZER31', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZER31 + complex(0,1)*iZER31', 
	 texname = '\\text{ZER31}' ) 
 
ZER32 = 	 Parameter(name='ZER32', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZER32 + complex(0,1)*iZER32', 
	 texname = '\\text{ZER32}' ) 
 
ZER33 = 	 Parameter(name='ZER33', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rZER33 + complex(0,1)*iZER33', 
	 texname = '\\text{ZER33}' ) 
 
Vv11 = 	 Parameter(name='Vv11', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv11 + complex(0,1)*iVv11', 
	 texname = '\\text{Vv11}' ) 
 
Vv12 = 	 Parameter(name='Vv12', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv12 + complex(0,1)*iVv12', 
	 texname = '\\text{Vv12}' ) 
 
Vv13 = 	 Parameter(name='Vv13', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv13 + complex(0,1)*iVv13', 
	 texname = '\\text{Vv13}' ) 
 
Vv14 = 	 Parameter(name='Vv14', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv14 + complex(0,1)*iVv14', 
	 texname = '\\text{Vv14}' ) 
 
Vv15 = 	 Parameter(name='Vv15', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv15 + complex(0,1)*iVv15', 
	 texname = '\\text{Vv15}' ) 
 
Vv16 = 	 Parameter(name='Vv16', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv16 + complex(0,1)*iVv16', 
	 texname = '\\text{Vv16}' ) 
 
Vv21 = 	 Parameter(name='Vv21', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv21 + complex(0,1)*iVv21', 
	 texname = '\\text{Vv21}' ) 
 
Vv22 = 	 Parameter(name='Vv22', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv22 + complex(0,1)*iVv22', 
	 texname = '\\text{Vv22}' ) 
 
Vv23 = 	 Parameter(name='Vv23', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv23 + complex(0,1)*iVv23', 
	 texname = '\\text{Vv23}' ) 
 
Vv24 = 	 Parameter(name='Vv24', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv24 + complex(0,1)*iVv24', 
	 texname = '\\text{Vv24}' ) 
 
Vv25 = 	 Parameter(name='Vv25', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv25 + complex(0,1)*iVv25', 
	 texname = '\\text{Vv25}' ) 
 
Vv26 = 	 Parameter(name='Vv26', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv26 + complex(0,1)*iVv26', 
	 texname = '\\text{Vv26}' ) 
 
Vv31 = 	 Parameter(name='Vv31', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv31 + complex(0,1)*iVv31', 
	 texname = '\\text{Vv31}' ) 
 
Vv32 = 	 Parameter(name='Vv32', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv32 + complex(0,1)*iVv32', 
	 texname = '\\text{Vv32}' ) 
 
Vv33 = 	 Parameter(name='Vv33', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv33 + complex(0,1)*iVv33', 
	 texname = '\\text{Vv33}' ) 
 
Vv34 = 	 Parameter(name='Vv34', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv34 + complex(0,1)*iVv34', 
	 texname = '\\text{Vv34}' ) 
 
Vv35 = 	 Parameter(name='Vv35', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv35 + complex(0,1)*iVv35', 
	 texname = '\\text{Vv35}' ) 
 
Vv36 = 	 Parameter(name='Vv36', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv36 + complex(0,1)*iVv36', 
	 texname = '\\text{Vv36}' ) 
 
Vv41 = 	 Parameter(name='Vv41', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv41 + complex(0,1)*iVv41', 
	 texname = '\\text{Vv41}' ) 
 
Vv42 = 	 Parameter(name='Vv42', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv42 + complex(0,1)*iVv42', 
	 texname = '\\text{Vv42}' ) 
 
Vv43 = 	 Parameter(name='Vv43', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv43 + complex(0,1)*iVv43', 
	 texname = '\\text{Vv43}' ) 
 
Vv44 = 	 Parameter(name='Vv44', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv44 + complex(0,1)*iVv44', 
	 texname = '\\text{Vv44}' ) 
 
Vv45 = 	 Parameter(name='Vv45', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv45 + complex(0,1)*iVv45', 
	 texname = '\\text{Vv45}' ) 
 
Vv46 = 	 Parameter(name='Vv46', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv46 + complex(0,1)*iVv46', 
	 texname = '\\text{Vv46}' ) 
 
Vv51 = 	 Parameter(name='Vv51', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv51 + complex(0,1)*iVv51', 
	 texname = '\\text{Vv51}' ) 
 
Vv52 = 	 Parameter(name='Vv52', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv52 + complex(0,1)*iVv52', 
	 texname = '\\text{Vv52}' ) 
 
Vv53 = 	 Parameter(name='Vv53', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv53 + complex(0,1)*iVv53', 
	 texname = '\\text{Vv53}' ) 
 
Vv54 = 	 Parameter(name='Vv54', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv54 + complex(0,1)*iVv54', 
	 texname = '\\text{Vv54}' ) 
 
Vv55 = 	 Parameter(name='Vv55', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv55 + complex(0,1)*iVv55', 
	 texname = '\\text{Vv55}' ) 
 
Vv56 = 	 Parameter(name='Vv56', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv56 + complex(0,1)*iVv56', 
	 texname = '\\text{Vv56}' ) 
 
Vv61 = 	 Parameter(name='Vv61', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv61 + complex(0,1)*iVv61', 
	 texname = '\\text{Vv61}' ) 
 
Vv62 = 	 Parameter(name='Vv62', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv62 + complex(0,1)*iVv62', 
	 texname = '\\text{Vv62}' ) 
 
Vv63 = 	 Parameter(name='Vv63', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv63 + complex(0,1)*iVv63', 
	 texname = '\\text{Vv63}' ) 
 
Vv64 = 	 Parameter(name='Vv64', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv64 + complex(0,1)*iVv64', 
	 texname = '\\text{Vv64}' ) 
 
Vv65 = 	 Parameter(name='Vv65', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv65 + complex(0,1)*iVv65', 
	 texname = '\\text{Vv65}' ) 
 
Vv66 = 	 Parameter(name='Vv66', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'rVv66 + complex(0,1)*iVv66', 
	 texname = '\\text{Vv66}' ) 
 
G = 	 Parameter(name='G', 
	 nature = 'internal', 
	 type = 'real', 
	 value = '2*cmath.sqrt(aS)*cmath.sqrt(cmath.pi)', 
	 texname = 'G') 
 
el = 	 Parameter(name='el', 
	 nature = 'internal', 
	 type = 'real', 
	 value = '2*cmath.sqrt(1/aEWM1)*cmath.sqrt(cmath.pi)', 
	 texname = 'el') 
 
MWp = 	 Parameter(name='MWp', 
	 nature = 'internal', 
	 type = 'real', 
	 value = 'cmath.sqrt(MZ**2/2. + cmath.sqrt(MZ**4/4. - (MZ**2*cmath.pi)/(cmath.sqrt(2)*aEWM1*Gf)))', 
	 texname = 'MWp') 
 
TW = 	 Parameter(name='TW', 
	 nature = 'internal', 
	 type = 'real', 
	 value = 'cmath.asin(cmath.sqrt(1 - MWp**2/MZ**2))', 
	 texname = 'TW') 
 
g1 = 	 Parameter(name='g1', 
	 nature = 'internal', 
	 type = 'real', 
	 value = 'el*1./cmath.cos(TW)', 
	 texname = 'g1') 
 
g2 = 	 Parameter(name='g2', 
	 nature = 'internal', 
	 type = 'real', 
	 value = 'el*1./cmath.sin(TW)', 
	 texname = 'g2') 
 
v = 	 Parameter(name='v', 
	 nature = 'internal', 
	 type = 'real', 
	 value = '2*cmath.sqrt(MWp**2/g2**2)', 
	 texname = 'v') 
 
Yu11 = 	 Parameter(name='Yu11', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = '(cmath.sqrt(2)*Mu1)/v', 
	 texname = 'Yu11') 
 
Yu12 = 	 Parameter(name='Yu12', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = '1.*(0)', 
	 texname = 'Yu12') 
 
Yu13 = 	 Parameter(name='Yu13', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = '1.*(0)', 
	 texname = 'Yu13') 
 
Yu21 = 	 Parameter(name='Yu21', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = '1.*(0)', 
	 texname = 'Yu21') 
 
Yu22 = 	 Parameter(name='Yu22', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = '(cmath.sqrt(2)*Mu2)/v', 
	 texname = 'Yu22') 
 
Yu23 = 	 Parameter(name='Yu23', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = '1.*(0)', 
	 texname = 'Yu23') 
 
Yu31 = 	 Parameter(name='Yu31', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = '1.*(0)', 
	 texname = 'Yu31') 
 
Yu32 = 	 Parameter(name='Yu32', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = '1.*(0)', 
	 texname = 'Yu32') 
 
Yu33 = 	 Parameter(name='Yu33', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = '(cmath.sqrt(2)*Mu3)/v', 
	 texname = 'Yu33') 
 
Yd11 = 	 Parameter(name='Yd11', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = '(cmath.sqrt(2)*Md1)/v', 
	 texname = 'Yd11') 
 
Yd12 = 	 Parameter(name='Yd12', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = '1.*(0)', 
	 texname = 'Yd12') 
 
Yd13 = 	 Parameter(name='Yd13', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = '1.*(0)', 
	 texname = 'Yd13') 
 
Yd21 = 	 Parameter(name='Yd21', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = '1.*(0)', 
	 texname = 'Yd21') 
 
Yd22 = 	 Parameter(name='Yd22', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = '(cmath.sqrt(2)*Md2)/v', 
	 texname = 'Yd22') 
 
Yd23 = 	 Parameter(name='Yd23', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = '1.*(0)', 
	 texname = 'Yd23') 
 
Yd31 = 	 Parameter(name='Yd31', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = '1.*(0)', 
	 texname = 'Yd31') 
 
Yd32 = 	 Parameter(name='Yd32', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = '1.*(0)', 
	 texname = 'Yd32') 
 
Yd33 = 	 Parameter(name='Yd33', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = '(cmath.sqrt(2)*Md3)/v', 
	 texname = 'Yd33') 
 
Ye11 = 	 Parameter(name='Ye11', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = '(cmath.sqrt(2)*Me1)/v', 
	 texname = 'Ye11') 
 
Ye12 = 	 Parameter(name='Ye12', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = '1.*(0)', 
	 texname = 'Ye12') 
 
Ye13 = 	 Parameter(name='Ye13', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = '1.*(0)', 
	 texname = 'Ye13') 
 
Ye21 = 	 Parameter(name='Ye21', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = '1.*(0)', 
	 texname = 'Ye21') 
 
Ye22 = 	 Parameter(name='Ye22', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = '(cmath.sqrt(2)*Me2)/v', 
	 texname = 'Ye22') 
 
Ye23 = 	 Parameter(name='Ye23', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = '1.*(0)', 
	 texname = 'Ye23') 
 
Ye31 = 	 Parameter(name='Ye31', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = '1.*(0)', 
	 texname = 'Ye31') 
 
Ye32 = 	 Parameter(name='Ye32', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = '1.*(0)', 
	 texname = 'Ye32') 
 
Ye33 = 	 Parameter(name='Ye33', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = '(cmath.sqrt(2)*Me3)/v', 
	 texname = 'Ye33') 
 
Lam = 	 Parameter(name='Lam', 
	 nature = 'internal', 
	 type = 'complex', 
	 value = 'Mh**2/v**2', 
	 texname = 'Lam') 
 
RXiWp = 	 Parameter(name='RXiWp', 
	 nature = 'internal', 
	 type = 'real', 
	 value = '1.', 
	 texname = 'RXiWp') 
 
RXiZ = 	 Parameter(name='RXiZ', 
	 nature = 'internal', 
	 type = 'real', 
	 value = '1.', 
	 texname = 'RXiZ') 
 
HPP1 = 	 Parameter(name='HPP1', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{HPP1}', 
	 lhablock = 'EFFHIGGSCOUPLINGS', 
	 lhacode = [25,22,22] ) 
 
HGG1 = 	 Parameter(name='HGG1', 
	 nature = 'external', 
	 type = 'real', 
	 value = 0., 
	 texname = '\\text{HGG1}', 
	 lhablock = 'EFFHIGGSCOUPLINGS', 
	 lhacode = [25,21,21] ) 
 
